
  # Healthy Meal Suggessions

  This is a code bundle for Healthy Meal Suggessions. The original project is available at https://www.figma.com/design/7BiQzQL1okE8QOmSryKwuB/Healthy-Meal-Suggessions.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  